opencv_version = "3.4.15.55"
contrib = False
headless = False
ci_build = True